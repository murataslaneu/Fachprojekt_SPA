plugins {
    id("java")
}

group = "org.example"
version = ""

repositories {
    mavenCentral()
}

dependencies {
    implementation(project(":ExampleHelper"))
}

tasks.test {
    useJUnitPlatform()
}