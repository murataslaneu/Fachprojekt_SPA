package com.example.db;

import com.example.db.adapters.PersistentTask;
import com.example.helper.api.TaskStatus;

import java.time.Instant;
import java.util.function.Predicate;

public class QueryBuilder {
    private String nameContains;
    private TaskStatus statusEquals;
    private Instant createdAfter;

    public QueryBuilder withNameContaining(String text) {
        this.nameContains = text;
        return this;
    }

    public QueryBuilder withStatus(TaskStatus status) {
        this.statusEquals = status;
        return this;
    }

    public QueryBuilder createdAfter(Instant timestamp) {
        this.createdAfter = timestamp;
        return this;
    }

    public Predicate<PersistentTask> build() {
        return task -> {
            if (nameContains != null && !task.getName().contains(nameContains)) return false;
            if (statusEquals != null && !task.getStatus().equals(statusEquals)) return false;
            if (createdAfter != null && task.getCreatedAt().isBefore(createdAfter)) return false;
            return true;
        };
    }
}
