package com.example.db.adapters;

import com.example.helper.api.Task;
import com.example.helper.api.TaskStatus;
import com.example.helper.exceptions.TaskExecutionException;

import java.time.Instant;

public class PersistentTask implements Task {

    private final String name;
    private final TaskStatus status;
    private final Instant createdAt;

    public PersistentTask(String name, TaskStatus status) {
        this.name = name;
        this.status = status;
        this.createdAt = Instant.now();
    }

    public String getName() {
        return name;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public static PersistentTask fromTask(Task task, TaskStatus status) {
        return new PersistentTask(task.getName(), status);
    }

    @Override
    public String toString() {
        return "PersistentTask[" + name + ", " + status + ", " + createdAt + "]";
    }

    @Override
    public int getId() {
        return name.hashCode();
    }

    @Override
    public void run() {
        throw new TaskExecutionException("PersistentTask is not executable");
    }
}
