package com.example.db;


import com.example.db.adapters.PersistentTask;
import com.example.helper.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class InMemoryDB {

    private final Map<String, PersistentTask> taskTable = new HashMap<>();

    public Map<String, PersistentTask> getTaskTable() {
        return taskTable;
    }

    // Violation: InMemoryDB should not access anything from com.example.helper
    // (as this shouldn't be needed)
    public String someRandomViolation() {
        return StringUtils.APPLICATION_NAME;
    }
}
