package com.example.db;

public class DBConnection {
    private final InMemoryDB db;

    public DBConnection(InMemoryDB db) {
        this.db = db;
    }

    public InMemoryDB getDB() {
        return db;
    }

    public static DBConnection connect() {
        return new DBConnection(new InMemoryDB());
    }
}
