package com.example.db;

import com.example.db.adapters.PersistentTask;
import com.example.db.utils.DBLogger;
import com.example.helper.Logger;
import com.example.helper.api.Task;
import com.example.helper.api.TaskStatus;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class DBTaskRepository {
    private final DBConnection connection;

    public DBTaskRepository(DBConnection connection) {
        this.connection = connection;
    }

    public void save(Task task, TaskStatus status) {
        PersistentTask persistent = PersistentTask.fromTask(task, status);
        // Should actually use DBLogger
        Logger.info("Saving persistent task: " + persistent);
        connection.getDB().getTaskTable().put(task.getName(), persistent);
    }

    public Optional<PersistentTask> findByName(String name) {
        DBLogger.info("Looking up persistent task: " + name);
        return Optional.ofNullable(connection.getDB().getTaskTable().get(name));
    }

    public List<PersistentTask> findAll() {
        return new ArrayList<>(connection.getDB().getTaskTable().values());
    }

    public void delete(String name) {
        Logger.info("Deleting persistent task: " + name);
        connection.getDB().getTaskTable().remove(name);
    }

    public boolean exists(String name) {
        return connection.getDB().getTaskTable().containsKey(name);
    }

    public List<PersistentTask> queryTasks(QueryBuilder builder) {
        Predicate<PersistentTask> predicate = builder.build();
        Logger.info("Running query...");
        return findAll().stream()
                .filter(predicate)
                .collect(Collectors.toList());
    }
}
