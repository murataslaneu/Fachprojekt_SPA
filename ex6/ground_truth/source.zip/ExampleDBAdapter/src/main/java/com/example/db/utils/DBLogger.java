package com.example.db.utils;

import com.example.helper.Logger;

public class DBLogger {
    public static void info(String message) {
        Logger.info(message, "DB");
    }

    public static void warn(String message) {
        Logger.warn(message, "DB");
    }

    public static void error(String message) {
        Logger.error(message, "DB");
    }
}
