plugins {
    id("java")
}

group = "org.example"
version = ""

repositories {
    mavenCentral()
}

dependencies {
    implementation(project(":ExampleHelper"))
    implementation(project(":ExampleDBAdapter"))
}

tasks.test {
    useJUnitPlatform()
}

tasks.jar {
    manifest {
        attributes(
            "Main-Class" to "com.example.main.Application",
            "Class-Path" to "ExampleHelper.jar ExampleDBAdapter.jar"
        )
    }
}