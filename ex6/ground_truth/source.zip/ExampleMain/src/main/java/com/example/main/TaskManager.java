package com.example.main;

import com.example.helper.Logger;
import com.example.helper.RetryPolicy;
import com.example.helper.api.Task;
import com.example.helper.api.Retryable;
import com.example.helper.api.TaskStatus;
import com.example.helper.exceptions.TaskExecutionException;

import java.util.HashMap;
import java.util.Map;

public class TaskManager {
    private final TaskFactory factory = new TaskFactory();

    private final Map<Task, TaskStatus> statusMap = new HashMap<>();

    public Task createAndExecute(String type, String name) throws TaskExecutionException {
        Task task = factory.createTask(type, name);
        statusMap.put(task, TaskStatus.PENDING);
        execute(task);
        return task;
    }

    public void execute(Task task) throws TaskExecutionException {
        Logger.info("Executing task: " + task.getName());
        statusMap.put(task, TaskStatus.RUNNING);

        try {
            if (task instanceof Retryable) {
                Retryable retryable = (Retryable) task;
                RetryPolicy.runWithRetry(retryable);
            } else {
                task.run();
            }

            statusMap.put(task, TaskStatus.COMPLETED);

        } catch (Exception e) {
            statusMap.put(task, TaskStatus.FAILED);
            throw new TaskExecutionException("Execution failed for task: " + task.getName(), e);
        }
    }

    public TaskStatus getTaskStatus(Task task) {
        return statusMap.get(task);
    }
}
