package com.example.main;

import com.example.db.DBConnection;
import com.example.db.InMemoryDB;
import com.example.db.QueryBuilder;
import com.example.db.adapters.PersistentTask;
import com.example.db.utils.DBLogger;
import com.example.helper.Logger;
import com.example.helper.StringUtils;
import com.example.helper.api.Task;
import com.example.helper.api.TaskStatus;
import com.example.helper.exceptions.TaskExecutionException;
import com.example.main.impl.DefaultTask;
import com.example.main.impl.UrgentTask;
import com.example.db.DBTaskRepository;

import java.util.List;

public class Application {

    public static void main(String[] args) {
        Logger.info("Starting application " + StringUtils.APPLICATION_NAME + "...");

        TaskManager manager = new TaskManager();
        // Violation: Should not use InMemoryDB directly
        // (Could be avoided here by using DBConnection.connect())
        DBConnection connection = new DBConnection(new InMemoryDB());
        DBTaskRepository repository = new DBTaskRepository(connection);

        List<Task> tasks = List.of(
                new DefaultTask("CleanUp"),
                new UrgentTask("RestartServer"),
                new DefaultTask("GenerateReport")
        );

        for (Task task : tasks) {
            try {
                manager.execute(task);
                repository.save(task, TaskStatus.COMPLETED);
            } catch (TaskExecutionException e) {
                Logger.error("Failed to execute task: " + task.getName() + ", " + task.getId());
                repository.save(task, TaskStatus.FAILED);
            }
        }

        QueryBuilder builder = new QueryBuilder()
                .withStatus(TaskStatus.COMPLETED)
                .withNameContaining("t");
        List<PersistentTask> matching = repository.queryTasks(builder);

        for (PersistentTask pt : matching) {
            Logger.info("Queried result: " + pt);
        }

        if (Logger.getErrors() > 0) {
            // Violation: Should use Logger instead of DBLogger
            DBLogger.warn("Application had " + Logger.getErrors() + " errors.");
        }
        Logger.info("Application finished.");
    }
}
