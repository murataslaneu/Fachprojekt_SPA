package com.example.main;

import com.example.db.adapters.PersistentTask;
import com.example.helper.api.Task;
import com.example.helper.api.TaskStatus;
import com.example.main.impl.DefaultTask;
import com.example.main.impl.UrgentTask;

public class TaskFactory {
    public Task createTask(String type, String name) {
        // Violation: PersistentTask should only be used within the context of the
        // DB and is not a task type like the other tasks
        if ("persistent".equalsIgnoreCase(type)) {
            return new PersistentTask(name, TaskStatus.PENDING);
        }
        else if ("urgent".equalsIgnoreCase(type)) {
            return new UrgentTask(name);
        } else {
            return new DefaultTask(name);
        }
    }
}
