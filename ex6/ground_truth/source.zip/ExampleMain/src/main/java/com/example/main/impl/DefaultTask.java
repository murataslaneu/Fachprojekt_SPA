package com.example.main.impl;

import com.example.helper.Logger;
import com.example.helper.api.Retryable;
import com.example.helper.api.Task;

// Violation: DefaultTask should not be retryable
public class DefaultTask implements Task, Retryable {

    private final String name;

    public DefaultTask(String name) {
        this.name = name;
    }

    @Override
    public void run() throws Exception {
        Logger.info("Running default task: " + name);
        // Doing stuff...
        Logger.info("Completed default task: " + name);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getId() {
        return name.hashCode();
    }

    @Override
    public void retry() throws Exception {
        run();
    }

    @Override
    public int maxRetries() {
        return 0;
    }
}
