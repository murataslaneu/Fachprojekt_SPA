package com.example.main.impl;

import com.example.helper.Logger;
import com.example.helper.api.Retryable;

public class UrgentTask extends DefaultTask implements Retryable {

    public UrgentTask(String name) {
        super(name);
    }

    @Override
    public void run() throws Exception {
        Logger.warn("Urgent task is running: " + getName());

        if (Math.random() < 0.5) {
            throw new Exception("Urgent task failed: " + getName());
        }

        Logger.info("Urgent task completed successfully: " + getName());
    }

    @Override
    public void retry() throws Exception {
        run();
    }

    @Override
    public int maxRetries() {
        return 3;
    }
}
