rootProject.name = "ground_truth_ex6_gr3"
include("ExampleMain", "ExampleHelper", "ExampleDBAdapter")