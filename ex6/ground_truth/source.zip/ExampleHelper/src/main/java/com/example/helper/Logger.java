package com.example.helper;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Logger {
    private static int errors = 0;

    public static void info(String message) {
        System.out.println(StringUtils.abbreviate("["+ getTime() + "] " + message, 200));
    }

    public static void info(String message, String messageOrigin) {
        System.out.println(StringUtils.abbreviate("[" + getTime() + "] [" + messageOrigin + "] " + message, 200));
    }

    public static void warn(String message) {
        System.out.print("[WARN] ");
        info(message);
    }

    public static void warn(String message, String messageOrigin) {
        System.out.print("[WARN] ");
        info(message, messageOrigin);
    }

    public static void error(String message) {
        System.err.println(StringUtils.abbreviate("[ERROR] ["+ getTime() + "] " + message, 200));
        errors++;
    }

    public static void error(String message, String messageOrigin) {
        System.err.println(StringUtils.abbreviate("[ERROR] [" + getTime() + "] [" + messageOrigin + "] " + message, 200));
        errors++;
    }

    public static int getErrors() {
        return errors;
    }

    public static String getTime() {
        return LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME);
    }
}
