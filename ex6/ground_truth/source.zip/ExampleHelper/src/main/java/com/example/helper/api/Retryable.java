package com.example.helper.api;

public interface Retryable {
    void retry() throws Exception;

    int maxRetries();
}