package com.example.helper.api;

public interface Identifiable {
    public int getId();
}
