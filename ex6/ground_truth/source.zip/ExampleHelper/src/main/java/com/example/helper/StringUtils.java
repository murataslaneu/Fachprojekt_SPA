package com.example.helper;

public class StringUtils {
    public static String APPLICATION_NAME = "ExampleMain";

    public static boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }

    public static String abbreviate(String input, int maxLen) {
        if (input == null || input.length() <= maxLen) return input;
        return input.substring(0, maxLen - 3) + "...";
    }
}
