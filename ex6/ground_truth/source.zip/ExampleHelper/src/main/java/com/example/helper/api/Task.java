package com.example.helper.api;

public interface Task extends Identifiable {
    void run() throws Exception;
    String getName();
}
