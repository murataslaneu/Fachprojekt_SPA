package com.example.helper.api;

public enum TaskStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED
}
