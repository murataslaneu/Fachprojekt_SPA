package com.example.helper;

import com.example.helper.api.Retryable;

public class RetryPolicy {
    public static void runWithRetry(Retryable task) throws Exception {
        int attempts = 0;
        int max = task.maxRetries();

        while (true) {
            try {
                task.retry();
                Logger.info("Retryable task succeeded on attempt " + (attempts + 1));
                return;
            } catch (Exception e) {
                attempts++;
                Logger.warn("Attempt " + attempts + " failed: " + e.getMessage());

                if (attempts >= max) {
                    Logger.error("Max retries reached.");
                    throw e;
                }
            }
        }
    }
}
