plugins {
    id("java")
}

allprojects {
    group = "com.example"
    version = "1.0"

    repositories {
        mavenCentral()
    }
}

subprojects {
    apply(plugin = "java")
    java {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    tasks.withType<Jar> {
        archiveBaseName.set(project.name)
    }
}
